/// FILE: [lib/core/services/firebase_service.dart]
/// SCOPO: [Factory centrale per tutti i servizi Firebase]
/// MODIFICHE: [Aggiunto OrdiniService al factory]
library;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'client_auth_service.dart';
import 'archive_service.dart';
import 'ordini_service.dart'; // ✅ AGGIUNTO

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  ClientAuthService get clientAuth => ClientAuthService(_firestore);
  ArchiveService get archive => ArchiveService(_firestore);
  OrdiniService get ordini => OrdiniService(_firestore); // ✅ NUOVO SERVICE
  
  FirebaseFirestore get firestore => _firestore;
}