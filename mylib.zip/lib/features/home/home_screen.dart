/// FILE: lib/presentation/pages/home_screen.dart
/// SCOPO: Schermata principale dell'app con navigazione e funzionalità di ordinazione
/// 
/// RELAZIONI CON ALTRI FILE:
/// - Importa: 
///   - 'package:provider/provider.dart' per gestione stato
///   - '../../core/providers/auth_provider.dart' per autenticazione
///   - '../../core/providers/session_provider.dart' per sessione tavolo
///   - '../../presentation/pages/menu_screen.dart' per schermata menu
///   - 'dialogs/qr_tavolo_dialog.dart' per dialog QR tavolo
///   - 'dialogs/selezione_tavolo_dialog.dart' per selezione tavolo prova
/// - Collegato a:
///   - MenuScreen - schermata ordinazione
///   - SessionProvider - gestione stato sessione
/// 
/// FUNZIONALITÀ PRINCIPALI:
/// - Navigazione Bottom Nav Bar (5 tab)
/// - Pulsante ORDINA con selezione tavolo e gestione sessione robusta
/// - Gestione sessione utente e tavolo
/// - Dialog selezione tavolo di prova
/// 
/// MODIFICHE APPLICATE:
/// - 2024-01-20 - Risolto loop navigazione con gestione asincrona corretta
/// - 2024-01-20 - Preservate tutte le funzionalità esistenti
/// 
/// DA VERIFICARE:
/// - Selezione tavolo ora funziona senza bloccare l'app
/// - La sessione viene creata correttamente
/// - Il checkout riconosce la sessione
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/session_provider.dart';
import '../../presentation/pages/menu_screen.dart';
import '../../presentation/pages/punti_screen.dart';
import '../../presentation/pages/altro_screen.dart';
import '../../presentation/pages/storico_ordini_screen.dart';
import '../../presentation/pages/login_screen.dart';
import 'widgets/bottom_nav_bar.dart';
import 'widgets/home_action_card.dart';
import 'widgets/offerte_placeholder.dart';
import 'widgets/home_header.dart';
import 'dialogs/qr_tavolo_dialog.dart';
import 'dialogs/selezione_tavolo_dialog.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  // Tab titles not needed for headerless layout

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _showQRCodeDialog() {
    showDialog(
      context: context,
      builder: (context) => const QrTavoloDialog(),
    );
  }

  // ✅ METODO OTTIMIZZATO PER GESTIONE ORDINE
  void _gestisciOrdine() {
    final sessionProvider = Provider.of<SessionProvider>(context, listen: false);
    
    if (sessionProvider.hasSessioneAttiva) {
      _navigaAlMenu();
    } else {
      _mostraSelezioneTavolo();
    }
  }

  void _navigaAlMenu() {
    setState(() {
      _currentIndex = 2;
    });
  }

  // ✅ METODO CORRETTO - RISOLVE IL LOOP
  void _mostraSelezioneTavolo() async {
    final numeroTavolo = await showDialog<String>(
      context: context,
      builder: (context) => SelezioneTavoloDialog(
        onTavoloSelezionato: (numero) {
          Navigator.of(context).pop(numero);
        },
      ),
    );
    if (!mounted) return;

    if (numeroTavolo != null) {
      final sessionProvider = Provider.of<SessionProvider>(context, listen: false);
      final numero = int.tryParse(numeroTavolo);
      
      if (numero != null) {
        sessionProvider.setTavolo(numero);
        _navigaAlMenu();
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Tavolo $numero selezionato ✓'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Widget _buildContent() {
    switch (_currentIndex) {
      case 0:
        return _buildHomeContent();
      case 1:
        return const OffertePlaceholder();
      case 2:
        return const MenuScreen();
      case 3:
        return const PuntiScreen();
      case 4:
        return const AltroScreen();
      default:
        return _buildHomeContent();
    }
  }

  // Intestazione rimossa: gestione titolo non pi  necessaria

  Widget _buildHomeContent() {
    final authProvider = Provider.of<AuthProvider>(context);
    final sessionProvider = Provider.of<SessionProvider>(context);

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: HomeHeader(
                    userName: authProvider.user?.nome,
                    hasSessioneAttiva: sessionProvider.hasSessioneAttiva,
                    numeroTavolo: sessionProvider.sessioneCorrente?.numeroTavolo,
                  ),
                ),
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(20),
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  children: [
                    HomeActionCard(
                      title: 'ORDINA',
                      icon: Icons.restaurant_menu,
                      color: const Color(0xFFFF6B8B),
                      onTap: _gestisciOrdine,
                    ),

                    HomeActionCard(
                      title: 'SCANSIONE QR',
                      icon: Icons.qr_code_scanner,
                      color: Colors.blue,
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Scansione QR - Feature in sviluppo'),
                            backgroundColor: Colors.blue,
                          ),
                        );
                      },
                    ),

                    // Nuove Card richieste
                    HomeActionCard(
                      title: 'I Miei Ordini',
                      icon: Icons.history,
                      color: Colors.orange,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => const StoricoOrdiniScreen()),
                        );
                      },
                    ),

                    HomeActionCard(
                      title: 'Info & Novità',
                      icon: Icons.info,
                      color: Colors.green,
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Info & Novità - in arrivo'),
                            backgroundColor: Colors.green,
                          ),
                        );
                      },
                    ),

                    HomeActionCard(
                      title: 'QR TAVOLO',
                      icon: Icons.qr_code_2,
                      color: Colors.cyan,
                      onTap: () {
                        if (sessionProvider.hasSessioneAttiva) {
                          _showQRCodeDialog();
                        } else {
                          _mostraSelezioneTavolo();
                        }
                      },
                    ),
                    
                    // Area Staff - sempre ultima posizione: apri LoginScreen
                    HomeActionCard(
                      title: 'Area Staff',
                      icon: Icons.lock,
                      color: Colors.deepPurple,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => const LoginScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      // Rimosso AppBar per layout full-bleed (header non desiderato)
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/splash.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          _buildContent(),
        ],
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTabTapped: _onTabTapped,
      ),
    );
  }
}