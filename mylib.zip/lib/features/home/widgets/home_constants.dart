class HomeConstants {
  static const List<String> tabTitles = <String>[
    'Home',
    'Offerte',
    'Ordina',
    'I Miei Punti',
    'Altro',
  ];
}


