import 'package:flutter/material.dart';
import '../widgets/offerta_card.dart' as offerta_widgets;

class OffertePage extends StatelessWidget {
  const OffertePage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> offerteSpeciali = [
      {
        'titolo': 'Menu Degustazione',
        'sottotitolo': '5 portate di alta cucina con selezione di vini abbinati',
        'prezzo': 45.00,
        'immagine': '🍽️',
        'pietanzeIncluse': [
          'Bruschette Miste',
          'Risotto ai Funghi',
          'Tagliata di Manzo',
          'Selezione di Formaggi',
          'Tiramisù Artigianale'
        ]
      },
      {
        'titolo': 'Aperitivo Serale',
        'sottotitolo': 'Cocktail esclusivi con stuzzichini della casa',
        'prezzo': 15.00,
        'immagine': '🍸',
        'pietanzeIncluse': [
          'Spritz Veneziano',
          'Negroni',
          'Stuzzichini Misti',
          'Olive Ascolane',
          'Tartine Creative'
        ]
      },
      {
        'titolo': 'Cena Romantica',
        'sottotitolo': 'Menu esclusivo per coppie con atmosfera intima',
        'prezzo': 60.00,
        'immagine': '💝',
        'pietanzeIncluse': [
          'Antipasto dell\'Amore',
          'Risotto allo Zafferano',
          'Filetto al Pepe Rosa',
          'Dolce Cuore di Cioccolato',
          'Calice di Prosecco'
        ]
      },
      {
        'titolo': 'Pranzo Business',
        'sottotitolo': 'Menu rapido ed elegante per meeting di lavoro',
        'prezzo': 25.00,
        'immagine': '💼',
        'pietanzeIncluse': [
          'Antipasto Veloce',
          'Primo della Casa',
          'Acqua o Bibita',
          'Caffè Espresso'
        ]
      },
    ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/splash.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          color: Colors.black.withOpacity(0.6),
          child: Column(
            children: [
              // Header
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFFFF6B8B).withOpacity(0.8),
                      const Color(0xFF4ECDC4).withOpacity(0.6),
                    ],
                  ),
                ),
                child: const Column(
                  children: [
                    Text(
                      'OFFERTE SPECIALI',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Scopri le nostre promozioni esclusive',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),

              // Lista offerte
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: offerteSpeciali.length,
                  itemBuilder: (context, index) {
                    final offerta = offerteSpeciali[index];
                    return offerta_widgets.OffertaCard(
                      offerta: offerta,
                      onTap: () {
                        _mostraDettaglioOfferta(context, offerta);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _mostraDettaglioOfferta(BuildContext context, Map<String, dynamic> offerta) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.9),
        title: Text(
          offerta['titolo'],
          style: const TextStyle(color: Colors.white),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                offerta['sottotitolo'],
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 16),
              const Text(
                'Include:',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              ...(offerta['pietanzeIncluse'] as List<String>).map((pietanza) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(
                  '• $pietanza',
                  style: const TextStyle(color: Colors.white70),
                ),
              )),
              const SizedBox(height: 16),
              Text(
                'Prezzo: €${offerta['prezzo'].toStringAsFixed(2)}',
                style: const TextStyle(
                  color: Color(0xFFFF6B8B),
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              'Chiudi',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Offerta "${offerta['titolo']}" aggiunta al carrello!'),
                  backgroundColor: const Color(0xFFFF6B8B),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF6B8B),
            ),
            child: const Text(
              'Aggiungi al Carrello',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}