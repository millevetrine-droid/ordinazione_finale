import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/cart_provider.dart';
import '../../core/providers/ordini_provider.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/session_provider.dart';
import '../../core/services/order_service.dart';
import '../../features/home/dialogs/selezione_tavolo_dialog.dart';

class CheckoutDialog extends StatefulWidget {
  const CheckoutDialog({super.key});

  @override
  State<CheckoutDialog> createState() => _CheckoutDialogState();
}

class _CheckoutDialogState extends State<CheckoutDialog> {
  final TextEditingController _noteController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Non auto-prompt: selezione tavolo avviene tramite pulsante 'Seleziona Tavolo' per evitare flicker
  }

  void _confermaOrdine(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context, listen: false);
    final ordiniProvider = Provider.of<OrdiniProvider>(context, listen: false);
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final sessionProvider = Provider.of<SessionProvider>(context, listen: false);

    // ✅ CORRETTO: Estrai le pietanze dai CartItem
    final pietanze = cartProvider.items.map((cartItem) => cartItem.pietanza).toList();

    // Proteggi contro sessione nulla: se la sessione non esiste, mostra messaggio e interrompi
    final sessione = sessionProvider.sessioneCorrente;
    if (sessione == null) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Sessione non valida. Seleziona un tavolo.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final ordine = OrderService.creaOrdine(
      numeroTavolo: sessione.numeroTavolo.toString(),
      pietanze: pietanze,
      idCameriere: authProvider.user?.username ?? 'cliente',
      note: _noteController.text.trim(),
    );

    ordiniProvider.aggiungiOrdine(ordine);
    cartProvider.svuotaCarrello();
    _noteController.clear();
    
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Ordine per Tavolo ${sessione.numeroTavolo} inviato alla cucina!'),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
  final cartProvider = Provider.of<CartProvider>(context);
  final sessionProvider = Provider.of<SessionProvider>(context); // listen: true by default
  final sessione = sessionProvider.sessioneCorrente;

    return AlertDialog(
      backgroundColor: Colors.black.withAlpha(230),
      title: const Text(
        'Conferma Ordine',
        style: TextStyle(color: Colors.white),
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 107, 139, 0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.table_restaurant, color: Color(0xFFFF6B8B)),
                  const SizedBox(width: 8),
                  // Mostra il numero del tavolo se esiste, altrimenti un messaggio chiaro
                  Builder(builder: (context) {
                    final s = Provider.of<SessionProvider>(context).sessioneCorrente;
                    if (s == null) {
                      return const Text(
                        'Sessione non valida',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    }
                    return Text(
                      'Tavolo ${s.numeroTavolo}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    );
                  }),
                ],
              ),
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _noteController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Note per la cucina (opzionale)',
                labelStyle: TextStyle(color: Colors.white),
                hintText: 'Es: Senza glutine, ben cotto...',
                hintStyle: TextStyle(color: Colors.white60),
              ),
              style: const TextStyle(color: Colors.white),
              maxLines: 3,
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withAlpha(128),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Riepilogo ordine:',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ✅ CORRETTO: Accedi a pietanza.nome e pietanza.prezzo tramite cartItem.pietanza
                  ...cartProvider.items.map((cartItem) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Row(
                      children: [
                        Text(
                          '• ${cartItem.pietanza.nome}',
                          style: const TextStyle(color: Colors.white70),
                        ),
                        if (cartItem.quantita > 1) ...[
                          Text(
                            ' x${cartItem.quantita}',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                        const Spacer(),
                        Text(
                          '€${(cartItem.pietanza.prezzo * cartItem.quantita).toStringAsFixed(2)}',
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  )),
                  const SizedBox(height: 8),
                  Text(
                    'Totale: €${cartProvider.totale.toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text(
            'Annulla',
            style: TextStyle(color: Colors.white),
          ),
        ),

        // Se non c'  sessione, mostra un pulsante per selezionare tavolo direttamente
        if (sessione == null) ...[
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF6B8B),
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              // Mostra il dialog per selezione tavolo e ottieni il numero selezionato
              final numeroTavolo = await showDialog<String>(
                context: context,
                builder: (context) => SelezioneTavoloDialog(
                  onTavoloSelezionato: (numero) {
                    Navigator.of(context).pop(numero);
                  },
                ),
              );

                  if (!context.mounted) return;

                  if (numeroTavolo != null) {
                    final numero = int.tryParse(numeroTavolo);
                    if (numero != null) {
                      Provider.of<SessionProvider>(context, listen: false).setTavolo(numero);
                      setState(() {});
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Tavolo $numero selezionato ✓'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    }
                  }
            },
            child: const Text(
              'Seleziona Tavolo',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],

        ElevatedButton(
          // Disabilita il pulsante se la sessione non esiste per evitare crash
          onPressed: sessione != null ? () => _confermaOrdine(context) : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFF6B8B),
          ),
          child: const Text(
            'INVIA ORDINE',
            style: TextStyle(color: Colors.white),
          ),
        ),
      ],
    );
  }
}